
def inpt(inp_type,text):
    return inp_type(input(text))
    
